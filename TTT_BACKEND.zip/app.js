const express = require('express');
const cors = require('cors');
const axios = require('axios').default;
const app = express();
const PORT = 8080;
app.use(cors());

app.get('/api/getResult',(req,res)=>{
    let result=[];
    const rollNumber = req.query.rollNumber.split(',');
    rollNumber.map(async(item,index)=>{
        await axios.get('https://terriblytinytales.com/testapi',{
            params:{
                rollnumber:item
            }
        }).then((response)=>{
            console.log(response.data)
            result.push({
                rollNumber:item,
                result:response.data
            })
        })    
    })
    res.send(result);
});

app.listen(process.env.PORT||PORT,()=>{
    console.log(`Server Listning to port ${process.env.PORT||PORT}`);
})